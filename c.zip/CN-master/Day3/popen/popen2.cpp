#include <bits/stdc++.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include<semaphore.h>

using namespace std;
int main(int argc, char  *argv[])
{
	char s[50];
	fputs("I love you",stdout);
	//cout<<strlen(s)<<endl;
	//cout<<s<<endl;
	return 0;
}
