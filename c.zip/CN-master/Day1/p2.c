#include<stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
	int c;
	printf("This is new  P2  Statement\n");

}