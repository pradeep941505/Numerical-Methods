#include<bits/stdc++.h>
using namespace std;
int main()
{
	sockaddr_in addrport;
	int sfd;
}
