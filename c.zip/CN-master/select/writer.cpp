#include <bits/stdc++.h>
using namespace std;
int main()
{
	char msg[1000];
	while(true)
	{
		bzero(msg,1000);
		fgets(msg,1000,stdin);
		fprintf(stdout,msg,1000);
	}
	return 0;
}

