#include<bits/stdc++.h>
using namespace std;
string cypher(string key, string text)
{
	string cypherText="";
	int i,j,k,keyMatrix[3][3],textMatrix[3][1],ans[3][1];
	for(i=0;i<9;i++)
		keyMatrix[i/3][i%3]=key[i]-'A';
	for(i=0;i<3;i++)
		textMatrix[i][0]=text[i]-'A';

	//multiplication
	for(i=0;i<3;i++)
	{
		ans[i][0]=0;
		for(j=0;j<3;j++) ans[i][0]=(ans[i][0]+keyMatrix[i][j]*textMatrix[j][0])%26;
		cypherText+=((char)('A'+ans[i][0]));
	}
	return cypherText;
}
int modInverse(int a, int m)
{
    a = a%m;
    for (int x=1; x<m; x++)
       if ((a*x) % m == 1)
          return x;
      cout<<"not coprime\n";
}
string decypher(string key,string cypher)
{
	string decrypt="";
	int i,j,k,keyMatrix[3][3],inverse[3][3],det,ans[3][3],textMatrix[3][1];
	for(i=0;i<9;i++)
		keyMatrix[i/3][i%3]=key[i]-'A';
	for(i=0;i<3;i++)
		textMatrix[i][0]=cypher[i]-'A';

	inverse[0][0]=(keyMatrix[1][1]*keyMatrix[2][2]-keyMatrix[1][2]*keyMatrix[2][1]);
	inverse[0][1]=(keyMatrix[0][2]*keyMatrix[2][1]-keyMatrix[0][1]*keyMatrix[2][2]);
	inverse[0][2]=(keyMatrix[0][1]*keyMatrix[1][2]-keyMatrix[0][2]*keyMatrix[1][1]);

	inverse[1][0]=(keyMatrix[1][2]*keyMatrix[2][0]-keyMatrix[1][0]*keyMatrix[2][2]);
	inverse[1][1]=(keyMatrix[0][0]*keyMatrix[2][2]-keyMatrix[0][2]*keyMatrix[2][0]);
	inverse[1][2]=(keyMatrix[0][2]*keyMatrix[1][0]-keyMatrix[0][0]*keyMatrix[1][2]);

	inverse[2][0]=(keyMatrix[1][0]*keyMatrix[2][1]-keyMatrix[1][1]*keyMatrix[2][0]);
	inverse[2][1]=(keyMatrix[0][1]*keyMatrix[2][0]-keyMatrix[0][0]*keyMatrix[2][1]);
	inverse[2][2]=(keyMatrix[0][0]*keyMatrix[1][1]-keyMatrix[0][1]*keyMatrix[1][0]);

	det=(inverse[0][0]*keyMatrix[0][0]+inverse[1][0]*keyMatrix[0][1]+inverse[2][0]*keyMatrix[0][2]);
	det=modInverse(det,26);cout<<det<<endl;

	for(i=0;i<3;i++){
		for(j=0;j<3;j++)
			{inverse[i][j]=((inverse[i][j]*det)%26+26*26)%26;cout<<inverse[i][j]<<" ";}
		cout<<endl;
	}
	//multiplication
	for(i=0;i<3;i++)
	{
		ans[i][0]=0;
		for(j=0;j<3;j++) ans[i][0]=(ans[i][0]+inverse[i][j]*textMatrix[j][0])%26;
		decrypt+=((char)('A'+ans[i][0]));
	}
	return decrypt;

}
int main()
{
	string key,text,ans;
	cin>>key>>text;
	ans=cypher(key,text);
	cout<<"Cypher:"<<ans<<endl;
	cout<<"Decypher:"<<decypher(key,ans)<<endl;
	return 0;
}