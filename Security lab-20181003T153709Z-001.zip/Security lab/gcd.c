#include <gmp.h>
#include <stdio.h>
#include <assert.h>

void init(mpz_t n)
{
    mpz_init(n);
    mpz_set_ui(n,0);
}

void input(mpz_t n)
{
    gmp_scanf("%Zd",n);
}

void output(mpz_t n)
{
    gmp_printf("%Zd\n",n);
}

void get_gcd(mpz_t a,mpz_t b,mpz_t res)
{
    while(mpz_cmp_si(b,0) != 0)
    {
        mpz_t temp;
        init(temp);

        mpz_mod(temp,a,b);
        mpz_set(a,b);
        mpz_set(b,temp);
    }
    mpz_set(res,a);
}

int main()
{
    mpz_t a,b,res;
    init(a);
    init(b);
    init(res);

    printf("Enter a : ");
    input(a);
    printf("Enter b : ");
    input(b);

    printf("a = ");
    output(a);

    printf("b = ");
    output(b);

    if(mpz_cmp (a,b) >= 0)
        get_gcd(a,b,res);
    else
        get_gcd(b,a,res);

    printf("GCD = ");
    output(res);

    return 0;
}