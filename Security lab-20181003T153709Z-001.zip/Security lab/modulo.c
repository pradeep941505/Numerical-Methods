#include <gmp.h>
#include <stdio.h>
#include <assert.h>
void init(mpz_t n)
{
    mpz_init(n);
    mpz_set_ui(n,0);
}
void input(mpz_t n)
{
    gmp_scanf("%Zd",n);
}
void output(mpz_t n)
{
    gmp_printf("%Zd\n",n);
}
int main()
{
	mpz_t a,b,n;
    init(a);
    init(b);
    init(n);

    printf("Enter a : ");
    input(a);
    printf("Enter b : ");
    input(b);
    printf("Enter n : ");
    input(n);

    mpz_t res1,res2,res3;
    init(res1);
    init(res2);
    init(res3);

    mpz_add(res1,a,b);
    mpz_mod(res1,res1,n);
    printf("(a+b) mod n is \n");
    output(res1);

    mpz_sub(res2,a,b);
    mpz_mod(res2,res2,n);
    printf("(a-b) mod n is \n");
    output(res2);

    mpz_mul(res3,a,b);
    mpz_mod(res3,res3,n);
    printf("(a*b) mod is \n");
    output(res3);
    
    return 0;
}