#include<bits/stdc++.h>
#include<gmp.h>
using namespace std;
int main()
{
	int i,j,k,n;
	mpz_t r[1000],m[1000];
	mpz_t temp,M,ans,temp1,temp2;mpz_inits(temp,temp1,temp2,M,ans,NULL);
	cin>>n;
	mpz_set_ui(M,1);
	for(i=0;i<n;i++) 
		{
			cin>>j>>k;
			mpz_inits(r[i],m[i],NULL);
			mpz_set_ui(r[i],j);
			mpz_set_ui(m[i],k);
			mpz_mul_ui(temp,M,k);
			mpz_set(M,temp);
		}

	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			if(i!=j)
			{
				mpz_gcd(temp,m[i],m[j]);
				if(mpz_cmp_ui(temp,0)>1)
				{
					cout<<"Not Coprimes\n";
					return 0;
				}
			}

	mpz_set_ui(ans,0);

	for(i=0;i<n;i++)
	{
		mpz_fdiv_q(temp,M,m[i]);
		mpz_invert(temp1,temp,m[i]);
		mpz_mul(temp2,temp1,temp);
		mpz_mul(temp1,temp2,r[i]);
		mpz_add(temp,temp1,ans);
		mpz_set(ans,temp);
	}
	mpz_fdiv_r(temp,ans,M);
	mpz_out_str(NULL,10,temp);
	cout<<endl;
	return 0;
}