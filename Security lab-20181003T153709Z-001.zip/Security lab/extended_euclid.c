#include <gmp.h>
#include <stdio.h>
#include <assert.h>

void init(mpz_t n)
{
    mpz_init(n);
    mpz_set_ui(n,0);
}

void input(mpz_t n)
{
    gmp_scanf("%Zd",n);
}

void output(mpz_t n)
{
    gmp_printf("%Zd\n",n);
    //printf("hello");
}
void swap(mpz_t a,mpz_t b)
{
	mpz_t temp;
	init(temp);
	mpz_set(temp,a);
	mpz_set(a,b);
	mpz_set(b,temp);
}
void get_gcd(mpz_t a,mpz_t b)
{
	
	mpz_t x0,y0;
	init(x0);
	init(y0);
	mpz_set_ui(x0,0);
	mpz_set_ui(y0,1);

	

	mpz_t x_1,y_1;
	init(x_1);
	init(y_1);
	mpz_set_ui(x_1,1);
	mpz_set_ui(y_1,0);

	

	while(mpz_cmp_si(b,0) != 0)
	{

		mpz_t q1,r1;
		init(q1);
		init(r1);

		mpz_fdiv_q(q1,a,b);
		mpz_fdiv_r(r1,a,b);

		mpz_t tx,ty;
		init(tx);
		init(ty);

		mpz_mul(tx,q1,x0);
		mpz_mul(ty,q1,y0);

		mpz_sub(x_1,x_1,tx);
		mpz_sub(y_1,y_1,ty);

		swap(x_1,x0);
		swap(y_1,y0);

		mpz_set(a,b);
		mpz_set(b,r1);
	}
	printf("Gcd is :");
	output(a);
	printf("X is :");
	output(x_1);
	printf("Y is :");
	output(y_1);
	//cout<<a<<" "<<x_1<<" "<<y_1<<endl;
}

int main()
{
	mpz_t a,b,res;
    init(a);
    init(b);
    init(res);

    printf("Enter a : ");
    input(a);
    printf("Enter b : ");
    input(b);

    printf("a = ");
    output(a);

    printf("b = ");
    output(b);

    get_gcd(a,b);

    return 0;
}
