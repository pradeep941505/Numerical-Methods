#include <bits/stdc++.h>
using namespace std;

void clear_zeros(vector<int> &v)
{
	while(v[0] == 0)
	{
		v.erase(v.begin());
	}
}

bool is_greater(vector<int> &A, vector<int> &B)
{
	int len1,len2;
	len1 = A.size();
	len2 = B.size();

	if(len1 > len2) return true;
	if(len1 < len2) return false;

	for(int i=0;i<len1;i++)
	{
		if(A[i] > B[i]) return true;
		if(A[i] < B[i]) return false;
	}
	return true;
}

vector<int> subtract(vector<int> &A, vector<int> &B)
{
	int len1,len2;
	len1 = A.size();
	len2 = B.size();

	int ind = len1-1;
	int jnd = len2-1;

	int borrow = 0;
	while(ind >=0 && jnd>=0)
	{
		if(A[ind] >= B[jnd])
		{
			A[ind] -= B[jnd];
			ind--;
			jnd--;
		}
		else
		{
			int k = ind-1;
			while(A[k] == 0)
			{
				k--;
			}
			A[k]--;
			k++;
			while(k!=ind)
			{
				A[k] = 9;
				k++;
			}
			A[ind] = A[ind]+10-B[jnd];
			ind--;
			jnd--;
		}
	}
	return A;
}
void print_num(vector<int> a)
{
	for(int i=0;i<a.size();i++)
	{
		cout<<a[i];
	}
	cout<<endl;
}
int main()
{
	vector<int> num1;
	vector<int> num2;
	int inp;

	cout<<"Enter Num1 : ";
	cin>>inp;
	while(inp!=-1)
	{
		num1.push_back(inp);
		cin>>inp;
	}
	print_num(num1);

	cout<<"Enter Num2 : ";
	cin>>inp;
	while(inp!=-1)
	{
		num2.push_back(inp);
		cin>>inp;
	}
	print_num(num2);

	clear_zeros(num1);
	clear_zeros(num2);

	while(is_greater(num1,num2))
	{
		num1 = subtract(num1,num2);
		clear_zeros(num1);
		cout<<"Num1 : ";
		print_num(num1);
	}

	return 0;
}