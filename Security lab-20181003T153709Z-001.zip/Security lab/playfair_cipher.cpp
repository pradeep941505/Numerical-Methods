#include <bits/stdc++.h>
using namespace std;

void print_mat(char mat[5][5])
{
	for(int x=0;x<5;x++)
	{
		for(int y=0;y<5;y++)
		{
			cout<<mat[x][y]<<" ";
		}
		cout<<endl;
	}
}
void search_mat(char mat[5][5],char ch,int &row,int &col)
{
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			if(mat[i][j] == ch)
			{
				row = i;
				col = j;
				return;
			}
		}
	}
}
string modify_text(string t)
{
	int ind=0;
	string text;
	string temp;
	while(ind<t.length())
	{
		if(t[ind] >= 'a' && t[ind] <= 'z')
		{
			temp.push_back(t[ind]);
		}
		ind++;
	}
	ind=0;

	while(ind < temp.length())
	{
		if(ind == temp.length()-1)
		{
			text,push_back(temp[ind]);
			ind++;
			continue;
		}
		char a,b;
		a = temp[ind];
		b = temp[ind+1];

		if(a==b)
		{
			b = 'x';
			ind++;
		}
		else
		{
			ind+=2;
		}
		text.push_back(a);
		text.push_back(b);
	
	}
	int len = text.length();
	if(len%2 == 1)
	{
		text.push_back('x');
	}
	return text;
}
string get_cipher(string text,char mat[5][5],bool encrypt)
{
	string res;
	int len = text.length();
	for(int i=0;i<len-1;i+=2)
	{
		int r1,c1;
		int r2,c2;
		char a,b;
		a = text[i];
		b = text[i+1];

		search_mat(mat,a,r1,c1);
		search_mat(mat,b,r2,c2);

		if(r1 != r2 && c1 != c2)
		{
			swap(r1,r2);
			res.push_back(mat[r2][c2]);
			res.push_back(mat[r1][c1]);	
		}
		else if(r1 == r2)
		{
			if(encrypt)
			{
				c1 = (c1+1)%5;
				c2 = (c2+1)%5;	
			}
			else
			{
				c1 = (c1+4)%5;
				c2 = (c2+4)%5;
			}
			res.push_back(mat[r1][c1]);
			res.push_back(mat[r2][c2]);
		}
		else
		{
			if(encrypt)
			{
				r1 = (r1+1)%5;
				r2 = (r2+1)%5;
			}
			else
			{
				r1 = (r1+4)%5;
				r2 = (r2+4)%5;
			}
			res.push_back(mat[r1][c1]);
			res.push_back(mat[r2][c2]);
		}

	}
	if(!encrypt)
	{
		len = res.length();
		string ans;
		for(int i=0;i<len;i++)
		{
			if(i!=0 && i!=len-1 && res[i] == 'x' && res[i-1]==res[i+1])
			{
				
			}
			else
			{
				ans.push_back(res[i]);
			}
		}
		return ans;
	}
	
	return res;
}

int main()
{
	string text;
	string key;

	cout<<"Enter the key : ";
	cin>>key;
	int visit[26];
	for(int i=0;i<26;i++)
		visit[i] = 0;
	visit[9] = 1;

	char mat[5][5];
	int i=0,j=0;

	for(int ind=0;ind<key.length();ind++)
	{
		mat[i][j] = key[ind];
		visit[key[ind]-'a']=1;

		j++;
		if(j==5)
		{
			j=0;
			i++;
		}
	}
	for(int p=0;p<26;p++)
	{
		if(visit[p]==0)
		{
			mat[i][j] = 'a'+p;
			visit[p]=1;
			j++;
			if(j==5)
			{
				j=0;
				i++;
			}
		}
	}
	print_mat(mat);

	cout<<"Enter Plain Text : ";
	cin>>text;
	text = modify_text(text);
	cout<<"The modified text is : "<<text<<endl;
	for( i=0;i<text.length();i++)
	{
		cout<<text[i]<<endl;
	}
	string cipher;
	cipher = get_cipher(text,mat,true);

	cout<<"The cipher text is : "<<cipher<<endl;
	cout<<"The text after Decryption is : "<<get_cipher(cipher,mat,false)<<endl;
	return 0;
}