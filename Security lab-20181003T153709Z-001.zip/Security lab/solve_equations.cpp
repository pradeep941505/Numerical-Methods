#include <gmp.h>
#include <stdio.h>
#include <assert.h>
#include <bits/stdc++.h>
using namespace std;

void init(mpz_t n)
{
    mpz_init(n);
    mpz_set_ui(n,0);
}

void input(mpz_t n)
{
    gmp_scanf("%Zd",n);
}

void output(mpz_t n)
{
    gmp_printf("%Zd\n",n);
}

void get_gcd(mpz_t a,mpz_t b,mpz_t res)
{
    while(mpz_cmp_si(b,0) != 0)
    {
        mpz_t temp;
        init(temp);

        mpz_mod(temp,a,b);
        mpz_set(a,b);
        mpz_set(b,temp);
    }
    mpz_set(res,a);
}

int main()
{
    int n;
    printf("enter the num of equns : ");
    cin>>n;

    mpz_t r[n];
    mpz_t m[n];

    mpz_t M;
    init(M);
    mpz_set_ui(M,1);

    for(int i=0;i<n;i++)
    {
        init(r[i]);
        init(m[i]);

        input(r[i]);
        input(m[i]);

        mpz_mul(M,M,m[i]);
    }
    
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            mpz_t gcd;
            init(gcd);

            mpz_gcd(gcd,m[i],m[j]);
            if(mpz_cmp_ui(gcd,1) != 0)
            {
                cout<<"Solution cant be found \n";
                return 0;
            }
        }
    }

    mpz_t res;
    init(res);

    for(int i=0;i<n;i++)
    {
        mpz_t temp;
        mpz_t inversion;
        init(temp);
        init(inversion);

        mpz_fdiv_q(temp,M,m[i]);
        mpz_set(inversion,temp);

        mpz_mul(temp,temp,r[i]);
        mpz_invert(inversion,inversion,m[i]);

        mpz_mul(temp,temp,inversion);

        mpz_add(res,res,temp);
    }
    mpz_fdiv_r(res,res,M);
    cout<<"res is : ";
    output(res);
    return 0;
}